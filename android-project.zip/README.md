# KeyTrack Pro Android — API 36

Este proyecto es el contenedor Android moderno para KeyTrack Pro v5.5.

Configuración:
- compileSdk 36
- targetSdk 36 (Android 16)
- minSdk 26
- Java 17
- Android Gradle Plugin 8.13.0
- Gradle 8.13

La app abre:
https://keytrack-pro.vercel.app

Incluye:
- permiso de cámara para el scanner web;
- soporte de getUserMedia() dentro del WebView;
- selector de archivos para fotos/PDF;
- DOM storage/cookies para sesión;
- tratamiento de barras del sistema en Android 16;
- navegación externa para enlaces que no sean de KeyTrack/Supabase.

## Generar APK en GitHub

1. Sube la carpeta `android-api36` a tu repositorio.
2. Conserva `.github/workflows/android-build.yml`.
3. En GitHub abre **Actions > Build Android APK > Run workflow**.
4. Al terminar, descarga el artefacto **KeyTrack-Pro-v5.5-Android16**.

El APK generado por ese workflow es DEBUG para pruebas.
Para publicar en Google Play se debe crear un AAB release firmado con tu keystore.
