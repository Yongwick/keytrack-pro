plugins {
    id("com.android.application")
}

android {
    namespace = "com.keytrackpro.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.keytrackpro.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 55
        versionName = "5.5"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
